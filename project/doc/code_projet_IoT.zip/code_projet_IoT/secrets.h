// Use this file to store all of the private credentials 
// and connection details

#define SECRET_SSID "Tel gaspard"		// replace MySSID with your WiFi network name
#define SECRET_PASS "12345678"	// replace MyPassword with your WiFi password

#define SECRET_CH_ID 1281249			// replace 0000000 with your channel number
#define SECRET_WRITE_APIKEY "095DAVCP2L62E1KG"   // replace XYZ with your channel write API Key
